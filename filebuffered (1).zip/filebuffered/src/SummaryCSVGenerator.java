import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SummaryCSVGenerator {

    public static void main(String[] args) {
        // Caminho do arquivo CSV de origem
        String inputFilePath = "C:/Users/Aluno_Tarde/Documents/BANCO DE DADOS CYAN/intelij/filebuffered/items.csv";

        // Caminho da pasta de saída para criar o arquivo summary.csv
        String outputDirectory = "C:/Users/Aluno_Tarde/Documents/BANCO DE DADOS CYAN/intelij/filebuffered/out";

        // Criação da pasta 'out' se não existir
        File outDir = new File(outputDirectory);
        if (!outDir.exists()) {
            outDir.mkdir(); // Cria a pasta 'out' se não existir
        }

        // Caminho completo do arquivo de saída
        String outputFilePath = outputDirectory + "/summary.csv";

        try {
            // Leitura do arquivo CSV de entrada
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));

            // Vetor para armazenar os itens
            List<Item> items = new ArrayList<>();

            String line;
            while ((line = reader.readLine()) != null) {
                // Dividir a linha com base na vírgula
                String[] columns = line.split(",");

                // Remover espaços extras ao redor de cada valor
                String itemName = columns[0].trim();
                double unitPrice = Double.parseDouble(columns[1].trim());
                int quantity = Integer.parseInt(columns[2].trim());

                // Criar um objeto Item e adicionar à lista
                Item item = new Item(itemName, unitPrice, quantity);
                items.add(item);
            }

            reader.close();

            // Criar o arquivo de saída
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));

            // Escrever no arquivo de saída
            for (Item item : items) {
                writer.write(item.getName() + " , " + item.getTotalValue() + " , " + item.getQuantity());
                writer.newLine(); // Nova linha no arquivo CSV de saída
            }

            // Fechar o escritor
            writer.close();

            System.out.println("Arquivo summary.csv gerado com sucesso!");

        } catch (IOException e) {
            System.err.println("Erro ao ler ou escrever arquivos: " + e.getMessage());
        }
    }
}
